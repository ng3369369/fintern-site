# Fintern.net

Edukacyjna platforma AI & Web3. Stworzona w Replit, hostowana przez Vercel.

## 🔧 Deployment

1. Utwórz repozytorium `fintern-site` na GitHub
2. Wgraj pliki z tej paczki (lub użyj `git init` i `git push`)
3. Podłącz repozytorium do Vercel (https://vercel.com/import/git)
4. Skonfiguruj domenę `fintern.net` oraz subdomeny w Namecheap zgodnie z poniższym

## 🌍 Rekordy DNS (Namecheap)

| Type | Host | Value                             | TTL       |
|------|------|-----------------------------------|-----------|
| CNAME | www  | cname.vercel-dns.com.            | Automatic |
| A     | @    | 76.76.21.21                       | Automatic |
| CNAME | kursy | cname.vercel-dns.com.           | Automatic |
| CNAME | ai   | cname.vercel-dns.com.            | Automatic |

## 🔒 SSL

Vercel automatycznie generuje certyfikaty SSL dla wszystkich domen.

## 📂 Struktura

Wersja bazowa to statyczna strona (HTML/CSS/JS), gotowa do rozbudowy.